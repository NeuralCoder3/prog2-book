package buggyCode;

public class BuggyClass implements InterfaceForBuggyClass {

	private int magic;

	BuggyClass() {
		this.magic = 42;
	}

	@Override
	public int sumNumbers(int num1, int num2) {
		return num1 + num2 + this.magic;
	}

	@Override
	public boolean equals(BuggyClass o) {

		if (o.magic == this.magic) {
			return true;
		}
		return false;
	}

	public static void main() {
		ChildOfBuggyClass b1 = new ChildOfBuggyClass();
		ChildOfBuggyClass b2 = new ChildOfBuggyClass();

		b1.printMagic();
		b2.printMagic();
		boolean eq = b1.equals(b2);
		System.out.println("Equal: " + eq);
	}

}
