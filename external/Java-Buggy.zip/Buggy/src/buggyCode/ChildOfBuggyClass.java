package buggyCode;

public class ChildOfBuggyClass extends BuggyClass {

	void printMagic() {
		System.out.println("Magic value: " + this.magic);
	}
}
