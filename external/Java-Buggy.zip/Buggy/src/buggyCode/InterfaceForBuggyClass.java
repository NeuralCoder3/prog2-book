package buggyCode;

public interface InterfaceForBuggyClass {

	int sumNumbers(int num1, int num2);

	int subtractNumbers(int num1, int num2);
}
