package firstJavaExercise;

public class MyFirstJava {

	public static void main(String[] args) {
	}

}
